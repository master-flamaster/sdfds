const express = require('express');
const app = express();
const path = require('path');
const ntp = require('./ntp');
const xor = require('./xor');
const logger = require('./logger');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../frontend/views'));
app.use(express.static(path.join(__dirname, '../frontend/public')));

app.get('/', async (req, res) => {
  try {
    const ntpData = await ntp.getNTPTime();
    const xorData = xor.getXORStatus();
    
    res.render('index', {
      ntp: {
        utcUnix: ntpData.utcUnix,
        serverUnix: ntpData.serverUnix,
        utc: ntpData.utc,
        local: ntpData.local
      },
      xor: {
        current: xorData.current,
        previous: xorData.previous,
        changed: xorData.changed,
        timestamp: new Date().toISOString()
      }
    });
    
    logger.info('Data sent to client', {
      xorStatus: xorData,
      ntp: ntpData
    });
  } catch (error) {
    logger.error('Render error', { error: error.message });
    res.status(500).send('Internal Server Error');
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  logger.info(`Server running on port ${PORT}`);
});