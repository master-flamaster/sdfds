const winston = require('winston');
const { format, transports } = winston;
const { combine, timestamp, printf, colorize } = format;

const logFormat = printf(({ level, message, timestamp, ...metadata }) => {
  let log = `${timestamp} [${level.toUpperCase()}] ${message}`;
  if (Object.keys(metadata).length > 0) log += ` ${JSON.stringify(metadata)}`;
  return log;
});

const logger = winston.createLogger({
  level: 'debug',
  format: combine(
    timestamp(),
    colorize(),
    logFormat
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: '../logs/combined.log' }),
    new winston.transports.File({ filename: '../logs/errors.log', level: 'error' })
  ]
});

module.exports = logger;