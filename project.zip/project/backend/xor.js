const os = require('os');
const crypto = require('crypto');

let previousXOR = null;

function calculateXOR() {
  const uptime = os.uptime();
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const xorValue = Math.floor(uptime) ^ Math.floor(totalMem / freeMem);
  return xorValue % 2;
}

function getXORStatus() {
  const currentXOR = calculateXOR();
  const changed = previousXOR !== null && previousXOR !== currentXOR;
  
  const result = {
    current: currentXOR,
    previous: previousXOR,
    changed,
    timestamp: new Date().toISOString(),
    userHash: crypto.createHash('sha256').update(crypto.randomBytes(16)).digest('hex')
  };
  
  previousXOR = currentXOR;
  return result;
}

module.exports = { getXORStatus };