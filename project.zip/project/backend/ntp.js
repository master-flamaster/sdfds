const ntpClient = require('ntp');

function getNTPTime() {
  return new Promise((resolve, reject) => {
    ntpClient.getNetworkTime('time.apple.com', 123, (err, date) => {
      if (err) return reject(err);
      resolve({
        utcUnix: Math.floor(date.getTime() / 1000),
        serverUnix: Math.floor(Date.now() / 1000),
        utc: date.toISOString(),
        local: date.toString()
      });
    });
  });
}

module.exports = { getNTPTime };