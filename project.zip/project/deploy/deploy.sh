#!/bin/bash

if [ "$EUID" -ne 0 ]; then
  echo "Please run the script as root"
  exit 1
fi

apt update && apt upgrade -y
apt install -y git curl wget build-essential

curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

npm install -g pm2

cd /opt
git clone https://github.com/yourusername/ntp-monitor.git
cd ntp-monitor

npm install

mkdir -p logs

pm2 start backend/server.js --no-daemon
pm2 startup
pm2 save

echo "Deployment completed!"
echo "App available on port 3000"